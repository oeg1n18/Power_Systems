function [outputArg1,outputArg2] = PVbus_solve(inputArg1,inputArg2)
%PVBUS_SOLVE Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

