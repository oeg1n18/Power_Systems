function get_data(inputArg1,inputArg2)
%GET_DATA Summary of this function goes here
%   Detailed explanation goes here
outputArg1 = inputArg1;
outputArg2 = inputArg2;
end

